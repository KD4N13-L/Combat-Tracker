grade = int(input("Your Grade, please "))
if grade < 60:
  print("Your Grade is F")
else:
  if grade < 70:
    print("Your Grade is D")
  else:
    if grade < 80:
      print("Your Grade is C")
    else:
      if grade < 90:
        print("Your Grade is B")
      else:
        if grade < 100:
          print("Your Grade is A")
